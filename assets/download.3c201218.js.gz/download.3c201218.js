import { a5 as openWindow } from "./index.327c7452.js";
import { u as urlToBase64, d as dataURLtoBlob } from "./base64Conver.08b9f4ec.js";
function downloadByOnlineUrl(url, filename, mime, bom) {
  urlToBase64(url).then((base64) => {
    downloadByBase64(base64, filename, mime, bom);
  });
}
function downloadByBase64(buf, filename, mime, bom) {
  const base64Buf = dataURLtoBlob(buf);
  downloadByData(base64Buf, filename, mime, bom);
}
function downloadByData(data, filename, mime, bom) {
  const blobData = typeof bom !== "undefined" ? [bom, data] : [data];
  const blob = new Blob(blobData, { type: mime || "application/octet-stream" });
  const blobURL = window.URL.createObjectURL(blob);
  const tempLink = document.createElement("a");
  tempLink.style.display = "none";
  tempLink.href = blobURL;
  tempLink.setAttribute("download", filename);
  if (typeof tempLink.download === "undefined") {
    tempLink.setAttribute("target", "_blank");
  }
  document.body.appendChild(tempLink);
  tempLink.click();
  document.body.removeChild(tempLink);
  window.URL.revokeObjectURL(blobURL);
}
function downloadByUrl({
  url,
  target = "_blank",
  fileName
}) {
  const isChrome = window.navigator.userAgent.toLowerCase().indexOf("chrome") > -1;
  const isSafari = window.navigator.userAgent.toLowerCase().indexOf("safari") > -1;
  if (/(iP)/g.test(window.navigator.userAgent)) {
    console.error("Your browser does not support download!");
    return false;
  }
  if (isChrome || isSafari) {
    const link = document.createElement("a");
    link.href = url;
    link.target = target;
    if (link.download !== void 0) {
      link.download = fileName || url.substring(url.lastIndexOf("/") + 1, url.length);
    }
    if (document.createEvent) {
      const e = document.createEvent("MouseEvents");
      e.initEvent("click", true, true);
      link.dispatchEvent(e);
      return true;
    }
  }
  if (url.indexOf("?") === -1) {
    url += "?download";
  }
  openWindow(url, { target });
  return true;
}
export { downloadByData as a, downloadByBase64 as b, downloadByOnlineUrl as c, downloadByUrl as d };
