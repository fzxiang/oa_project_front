import { f as createVNode, bG as Badge } from "./vendor.faf2de98.js";
/* empty css                  */const refundTimeTableSchema = [{
  title: "\u65F6\u95F4",
  width: 150,
  dataIndex: "t1"
}, {
  title: "\u5F53\u524D\u8FDB\u5EA6",
  width: 150,
  dataIndex: "t2"
}, {
  title: "\u72B6\u6001",
  width: 150,
  dataIndex: "t3",
  customRender: ({
    record
  }) => {
    return createVNode(Badge, {
      "status": "success",
      "text": record.t3
    }, null);
  }
}, {
  title: "\u64CD\u4F5C\u5458ID	",
  width: 150,
  dataIndex: "t4"
}, {
  title: "\u8017\u65F6",
  width: 150,
  dataIndex: "t5"
}];
const refundTimeTableData = [{
  t1: "2017-10-01 14:10",
  t2: "\u8054\u7CFB\u5BA2\u6237",
  t3: "\u8FDB\u884C\u4E2D",
  t4: "\u53D6\u8D27\u5458 ID1234",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u53D6\u8D27\u5458\u51FA\u53D1",
  t3: "\u6210\u529F",
  t4: "\u53D6\u8D27\u5458 ID1234",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u53D6\u8D27\u5458\u63A5\u5355",
  t3: "\u6210\u529F",
  t4: "\u7CFB\u7EDF",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u7533\u8BF7\u5BA1\u6279\u901A\u8FC7",
  t3: "\u6210\u529F",
  t4: "\u7528\u6237",
  t5: "1h"
}];
export { refundTimeTableData, refundTimeTableSchema };
