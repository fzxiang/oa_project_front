import { a as PageWrapper } from "./index.5130582f.js";
import { _ as _export_sfc } from "./index.4dc0081b.js";
import { d as defineComponent, r as resolveComponent, o as openBlock, c as createBlock, e as withCtx, V as createBaseVNode } from "./vendor.faf2de98.js";
import "./index.31fe8755.js";
import "./useRootSetting.f743f654.js";
/* empty css                  *//* empty css                  */import "./useWindowSizeFn.7703d3fa.js";
import "./useContentViewHeight.3baa48d8.js";
const _sfc_main = defineComponent({ components: { PageWrapper } });
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", null, "\u5B50\u7EA7\u8BE6\u60C5\u9875\u5185\u5BB9\u5728\u6B64", -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_PageWrapper = resolveComponent("PageWrapper");
  return openBlock(), createBlock(_component_PageWrapper, { title: "\u5B50\u7EA7\u8BE6\u60C5\u9875" }, {
    default: withCtx(() => [
      _hoisted_1
    ]),
    _: 1
  });
}
var ChildrenListDetail = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { ChildrenListDetail as default };
