import { B as Button } from "./index.45368269.js";
import { f as createVNode, bG as Badge } from "./vendor.faf2de98.js";
/* empty css                  */import "./index.89bba8b1.js";
import "./index.035cec88.js";
import "./useRootSetting.b4af9267.js";
import "./useAttrs.d4bdb35c.js";
const refundData = {
  a1: "1000000000",
  a2: "\u5DF2\u53D6\u8D27",
  a3: "1234123421",
  a4: "3214321432"
};
const personData = {
  b1: "\u4ED8\u5C0F\u5C0F",
  b2: "18100000000",
  b3: "\u83DC\u9E1F\u4ED3\u50A8",
  b4: "\u6D59\u6C5F\u7701\u676D\u5DDE\u5E02\u897F\u6E56\u533A\u4E07\u5858\u8DEF18\u53F7",
  b5: "\u65E0"
};
const refundSchema = [{
  field: "a1",
  label: "\u53D6\u8D27\u5355\u53F7"
}, {
  field: "a2",
  label: "\u72B6\u6001"
}, {
  field: "a3",
  label: "\u9500\u552E\u5355\u53F7"
}, {
  field: "a4",
  label: "\u5B50\u8BA2\u5355"
}];
const personSchema = [{
  field: "b1",
  label: "\u7528\u6237\u59D3\u540D"
}, {
  field: "b2",
  label: "\u8054\u7CFB\u7535\u8BDD"
}, {
  field: "b3",
  label: "\u5E38\u7528\u5FEB\u9012"
}, {
  field: "b4",
  label: "\u53D6\u8D27\u5730\u5740"
}, {
  field: "b5",
  label: "\u5907\u6CE8"
}];
const refundTableSchema = [{
  title: "\u5546\u54C1\u7F16\u53F7",
  width: 150,
  dataIndex: "t1",
  customRender: ({
    record
  }) => {
    return createVNode(Button, {
      "type": "link",
      "size": "small"
    }, {
      default: () => record.t1
    });
  }
}, {
  title: "\u5546\u54C1\u540D\u79F0",
  width: 150,
  dataIndex: "t2"
}, {
  title: "\u5546\u54C1\u6761\u7801",
  width: 150,
  dataIndex: "t3"
}, {
  title: "\u5355\u4EF7	",
  width: 150,
  dataIndex: "t4"
}, {
  title: "\u6570\u91CF\uFF08\u4EF6\uFF09	",
  width: 150,
  dataIndex: "t5"
}, {
  title: "\u91D1\u989D",
  width: 150,
  dataIndex: "t6"
}];
const refundTimeTableSchema = [{
  title: "\u65F6\u95F4",
  width: 150,
  dataIndex: "t1"
}, {
  title: "\u5F53\u524D\u8FDB\u5EA6",
  width: 150,
  dataIndex: "t2"
}, {
  title: "\u72B6\u6001",
  width: 150,
  dataIndex: "t3",
  customRender: ({
    record
  }) => {
    return createVNode(Badge, {
      "status": "success",
      "text": record.t3
    }, null);
  }
}, {
  title: "\u64CD\u4F5C\u5458ID	",
  width: 150,
  dataIndex: "t4"
}, {
  title: "\u8017\u65F6",
  width: 150,
  dataIndex: "t5"
}];
const refundTableData = [{
  t1: 1234561,
  t2: "\u77FF\u6CC9\u6C34 550ml",
  t3: "12421432143214321",
  t4: "2.00",
  t5: 1,
  t6: 2
}, {
  t1: 1234562,
  t2: "\u77FF\u6CC9\u6C34 550ml",
  t3: "12421432143214321",
  t4: "2.00",
  t5: 2,
  t6: 2
}, {
  t1: 1234562,
  t2: "\u77FF\u6CC9\u6C34 550ml",
  t3: "12421432143214321",
  t4: "2.00",
  t5: 2,
  t6: 2
}, {
  t1: 1234562,
  t2: "\u77FF\u6CC9\u6C34 550ml",
  t3: "12421432143214321",
  t4: "2.00",
  t5: 2,
  t6: 2
}];
const refundTimeTableData = [{
  t1: "2017-10-01 14:10",
  t2: "\u8054\u7CFB\u5BA2\u6237",
  t3: "\u8FDB\u884C\u4E2D",
  t4: "\u53D6\u8D27\u5458 ID1234",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u53D6\u8D27\u5458\u51FA\u53D1",
  t3: "\u6210\u529F",
  t4: "\u53D6\u8D27\u5458 ID1234",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u53D6\u8D27\u5458\u63A5\u5355",
  t3: "\u6210\u529F",
  t4: "\u7CFB\u7EDF",
  t5: "5mins"
}, {
  t1: "2017-10-01 14:10",
  t2: "\u7533\u8BF7\u5BA1\u6279\u901A\u8FC7",
  t3: "\u6210\u529F",
  t4: "\u7528\u6237",
  t5: "1h"
}];
export { personData, personSchema, refundData, refundSchema, refundTableData, refundTableSchema, refundTimeTableData, refundTimeTableSchema };
