const mapData = [
  {
    name: "\u5317\u4EAC",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5929\u6D25",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u4E0A\u6D77",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u91CD\u5E86",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6CB3\u5317",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6CB3\u5357",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u4E91\u5357",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u8FBD\u5B81",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u9ED1\u9F99\u6C5F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6E56\u5357",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5B89\u5FBD",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5C71\u4E1C",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u65B0\u7586",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6C5F\u82CF",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6D59\u6C5F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6C5F\u897F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6E56\u5317",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5E7F\u897F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u7518\u8083",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5C71\u897F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5185\u8499\u53E4",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u9655\u897F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5409\u6797",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u798F\u5EFA",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u8D35\u5DDE",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5E7F\u4E1C",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u9752\u6D77",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u897F\u85CF",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u56DB\u5DDD",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u5B81\u590F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6D77\u5357",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u53F0\u6E7E",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u9999\u6E2F",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  },
  {
    name: "\u6FB3\u95E8",
    value: Math.round(Math.random() * 1e3),
    tipData: [Math.round(Math.random() * 1e3), Math.round(Math.random() * 1e3)]
  }
];
const getLineData = (() => {
  const category = [];
  let dottedBase = +new Date();
  const lineData = [];
  const barData = [];
  for (let i = 0; i < 20; i++) {
    const date = new Date(dottedBase += 1e3 * 3600 * 24);
    category.push([date.getFullYear(), date.getMonth() + 1, date.getDate()].join("-"));
    const b = Math.random() * 200;
    const d = Math.random() * 200;
    barData.push(b);
    lineData.push(d + b);
  }
  return { barData, category, lineData };
})();
export { getLineData as g, mapData as m };
