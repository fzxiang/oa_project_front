const navItems = [
  {
    title: "\u9996\u9875",
    icon: "ion:home-outline",
    color: "#1fdaca"
  },
  {
    title: "\u4EEA\u8868\u76D8",
    icon: "ion:grid-outline",
    color: "#bf0c2c"
  },
  {
    title: "\u7EC4\u4EF6",
    icon: "ion:layers-outline",
    color: "#e18525"
  },
  {
    title: "\u7CFB\u7EDF\u7BA1\u7406",
    icon: "ion:settings-outline",
    color: "#3fb27f"
  },
  {
    title: "\u6743\u9650\u7BA1\u7406",
    icon: "ion:key-outline",
    color: "#4daf1bc9"
  },
  {
    title: "\u56FE\u8868",
    icon: "ion:bar-chart-outline",
    color: "#00d8ff"
  }
];
const dynamicInfoItems = [
  {
    avatar: "dynamic-avatar-1|svg",
    name: "\u5A01\u5EC9",
    date: "\u521A\u521A",
    desc: `\u5728 <a>\u5F00\u6E90\u7EC4</a> \u521B\u5EFA\u4E86\u9879\u76EE <a>Vue</a>`
  },
  {
    avatar: "dynamic-avatar-2|svg",
    name: "\u827E\u6587",
    date: "1\u4E2A\u5C0F\u65F6\u524D",
    desc: `\u5173\u6CE8\u4E86 <a>\u5A01\u5EC9</a> `
  },
  {
    avatar: "dynamic-avatar-3|svg",
    name: "\u514B\u91CC\u65AF",
    date: "1\u5929\u524D",
    desc: `\u53D1\u5E03\u4E86 <a>\u4E2A\u4EBA\u52A8\u6001</a> `
  },
  {
    avatar: "dynamic-avatar-4|svg",
    name: "Vben",
    date: "2\u5929\u524D",
    desc: `\u53D1\u8868\u6587\u7AE0 <a>\u5982\u4F55\u7F16\u5199\u4E00\u4E2AVite\u63D2\u4EF6</a> `
  },
  {
    avatar: "dynamic-avatar-5|svg",
    name: "\u76AE\u7279",
    date: "3\u5929\u524D",
    desc: `\u56DE\u590D\u4E86 <a>\u6770\u514B</a> \u7684\u95EE\u9898 <a>\u5982\u4F55\u8FDB\u884C\u9879\u76EE\u4F18\u5316\uFF1F</a>`
  },
  {
    avatar: "dynamic-avatar-6|svg",
    name: "\u6770\u514B",
    date: "1\u5468\u524D",
    desc: `\u5173\u95ED\u4E86\u95EE\u9898 <a>\u5982\u4F55\u8FD0\u884C\u9879\u76EE</a> `
  },
  {
    avatar: "dynamic-avatar-1|svg",
    name: "\u5A01\u5EC9",
    date: "1\u5468\u524D",
    desc: `\u53D1\u5E03\u4E86 <a>\u4E2A\u4EBA\u52A8\u6001</a> `
  },
  {
    avatar: "dynamic-avatar-1|svg",
    name: "\u5A01\u5EC9",
    date: "2021-04-01 20:00",
    desc: `\u63A8\u9001\u4E86\u4EE3\u7801\u5230 <a>Github</a>`
  }
];
const groupItems = [
  {
    title: "Github",
    icon: "carbon:logo-github",
    color: "",
    desc: "\u4E0D\u8981\u7B49\u5F85\u673A\u4F1A\uFF0C\u800C\u8981\u521B\u9020\u673A\u4F1A\u3002",
    group: "\u5F00\u6E90\u7EC4",
    date: "2021-04-01"
  },
  {
    title: "Vue",
    icon: "ion:logo-vue",
    color: "#3fb27f",
    desc: "\u73B0\u5728\u7684\u4F60\u51B3\u5B9A\u5C06\u6765\u7684\u4F60\u3002",
    group: "\u7B97\u6CD5\u7EC4",
    date: "2021-04-01"
  },
  {
    title: "Html5",
    icon: "ion:logo-html5",
    color: "#e18525",
    desc: "\u6CA1\u6709\u4EC0\u4E48\u624D\u80FD\u6BD4\u52AA\u529B\u66F4\u91CD\u8981\u3002",
    group: "\u4E0A\u73ED\u6478\u9C7C",
    date: "2021-04-01"
  },
  {
    title: "Angular",
    icon: "ion:logo-angular",
    color: "#bf0c2c",
    desc: "\u70ED\u60C5\u548C\u6B32\u671B\u53EF\u4EE5\u7A81\u7834\u4E00\u5207\u96BE\u5173\u3002",
    group: "UI",
    date: "2021-04-01"
  },
  {
    title: "React",
    icon: "bx:bxl-react",
    color: "#00d8ff",
    desc: "\u5065\u5EB7\u7684\u8EAB\u4F53\u662F\u5B9E\u76EE\u6807\u7684\u57FA\u77F3\u3002",
    group: "\u6280\u672F\u725B",
    date: "2021-04-01"
  },
  {
    title: "Js",
    icon: "ion:logo-javascript",
    color: "#4daf1bc9",
    desc: "\u8DEF\u662F\u8D70\u51FA\u6765\u7684\uFF0C\u800C\u4E0D\u662F\u7A7A\u60F3\u51FA\u6765\u7684\u3002",
    group: "\u67B6\u6784\u7EC4",
    date: "2021-04-01"
  }
];
export { dynamicInfoItems as d, groupItems as g, navItems as n };
